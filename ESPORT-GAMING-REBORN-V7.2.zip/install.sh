SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

ui_print "
╭━━━┳━━━╮╭━━━┳━━━┳━━╮╭━━━┳━━━┳━╮╱╭╮
┃╭━━┫╭━╮┃┃╭━╮┃╭━━┫╭╮┃┃╭━╮┃╭━╮┃┃╰╮┃┃
┃╰━━┫┃╱╰╯┃╰━╯┃╰━━┫╰╯╰┫┃╱┃┃╰━╯┃╭╮╰╯┃
┃╭━━┫┃╭━╮┃╭╮╭┫╭━━┫╭━╮┃┃╱┃┃╭╮╭┫┃╰╮┃┃
┃╰━━┫╰┻━┃┃┃┃╰┫╰━━┫╰━╯┃╰━╯┃┃┃╰┫┃╱┃┃┃
╰━━━┻━━━╯╰╯╰━┻━━━┻━━━┻━━━┻╯╰━┻╯╱╰━╯"
ui_print " スポーツゲーミングが生まれ変わる"
ui_print " Ver : 7.2 "
ui_print " Support : https://t.me/HenVx1 "
ui_print ""
ui_print " Installing Down. "
ui_print ""
ui_print ""
ui_print ""
ui_print ""
ui_print " Done. "